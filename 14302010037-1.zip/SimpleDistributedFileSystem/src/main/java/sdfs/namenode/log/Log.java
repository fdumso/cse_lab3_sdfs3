package sdfs.namenode.log;

import java.io.Serializable;

public interface Log extends Serializable {
}
