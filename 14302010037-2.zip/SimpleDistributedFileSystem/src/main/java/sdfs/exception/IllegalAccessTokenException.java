package sdfs.exception;

public class IllegalAccessTokenException extends IllegalStateException {
    private static final long serialVersionUID = 2929329431160799971L;
}
