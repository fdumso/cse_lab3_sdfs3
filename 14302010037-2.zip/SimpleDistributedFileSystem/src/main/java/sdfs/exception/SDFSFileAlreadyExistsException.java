package sdfs.exception;

import java.io.IOException;

public class SDFSFileAlreadyExistsException extends IOException {
    private static final long serialVersionUID = 7961390745557242210L;
}
